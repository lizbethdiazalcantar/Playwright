import { Page, expect } from '@playwright/test';
import { TextbookPage } from '../textbookPage';

export class OverviewUnitTestsInCplusPlus extends TextbookPage{
  page: Page;

  constructor(page: Page) {
    super(page);
    this.page = page;
  }

  //.......Selectors..............//

  saveAndRunButton = '//button[@class="btn btn-success run-button"]'
  outPutArea = '#cpp_units_stdout'
  showCodeLens = '//button[@class="ac_opt btn btn-default"]'
  hideCodeLens = '//button[@class="ac_opt btn btn-default"]'
  codelensBox = "#cpp_units_codelens"
  showSource = "#catch2_src_show"
  hideSource = "#catch2_src_hide"
  sourceBox = "div.highlight-default.notranslate"
  reformatButton = "//button[@class='ac_opt btn btn-default']"
  codeMirrorFirstLine = '.CodeMirror-line'
  errorAlert =  '.error.alert.alert-danger'
  


}