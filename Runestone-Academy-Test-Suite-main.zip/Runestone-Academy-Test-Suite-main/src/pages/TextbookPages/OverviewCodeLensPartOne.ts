import { Page, expect, Locator } from '@playwright/test';
import { TextbookPage } from '../textbookPage';

export class OverviewCodeLensPartOne extends TextbookPage {
  readonly page: Page;

  // XPath selectors for the first CodeLens block by default (index=1)

    nextButton: Locator;
    prevButton: Locator;
    printTextArea: Locator;
    curInstr: Locator;
    redArrow: Locator;


  constructor(page: Page, codeLensIndex: number = 1) {
    super(page);
    this.page = page;

    // XPath with dynamic index for multiple CodeLens instances
    // Adjust paths as needed based on your page structure

    this.nextButton = page.locator(`xpath=(/html/body/div[3]/section[1]/div[${codeLensIndex}]/div/div[2]/div/table/tbody/tr/td[1]/div/div[2]/div[3]/button[3])`);
    this.prevButton = page.locator(`xpath=(/html/body/div[3]/section[1]/div[${codeLensIndex}]/div/div[2]/div/table/tbody/tr/td[1]/div/div[2]/div[3]/button[2])`);
    this.printTextArea = page.locator(`xpath=(/html/body/div[3]/section[1]/div[${codeLensIndex}]/div/div[2]/div/table/tbody/tr/td[1]/div/div[1]/textarea[@id='pyStdout'])`);
    this.curInstr = page.locator(`xpath=(/html/body/div[3]/section[1]/div[${codeLensIndex}]/div/div[2]/div/table/tbody/tr/td[1]/div/div[2]/div[4])`);
    this.redArrow = page.locator(`xpath=(/html/body/div[3]/section[1]/div[${codeLensIndex}]/div/div[2]/div/table/tbody/tr/td[1]/div//span[contains(@class,'red-arrow')])`);
  
  }

  async clickNext(times = 1) {
    for (let i = 0; i < times; i++) {
      await this.nextButton.waitFor({ state: 'visible' });
      await this.nextButton.click();
      await this.page.waitForTimeout(500);
    }
  }

  async clickPrev(times = 1) {
    for (let i = 0; i < times; i++) {
      await this.prevButton.waitFor({ state: 'visible' });
      await this.prevButton.click();
      await this.page.waitForTimeout(500);
    }
  }

  async verifyCurrentStepText(expectedText: string) {
    await expect(this.curInstr).toContainText(expectedText);
  }

  async verifyButtonDisabled(button: Locator) {
    await expect(button).toBeDisabled();
  }

  async verifyPrintOutputContains(expectedText: string) {
    await expect(this.printTextArea).toContainText(expectedText);
  }

  async redArrowIsVisible(shouldBeVisible: boolean) {
    if (shouldBeVisible) {
      await expect(this.redArrow).toBeVisible();
    } else {
      await expect(this.redArrow).not.toBeVisible();
    }
  }
}
