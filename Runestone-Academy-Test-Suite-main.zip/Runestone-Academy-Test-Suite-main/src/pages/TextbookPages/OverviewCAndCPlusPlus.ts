import { Page, expect } from '@playwright/test';
import { TextbookPage } from '../textbookPage';

export class OverviewCAndCPlusPlus extends TextbookPage{
  page: Page;

  editorContainer1 = 'div#hw_in_c div[lang="c"] div.ac_code_div .CodeMirror.cm-s-default.ui-resizable';
  editorContainer1Focused = `${this.editorContainer1}.CodeMirror-focused`;
  saveAndRunButton = '//button[normalize-space(text())="Save & Run"]';
  showCodeLensButton = '//button[normalize-space(text())="Show CodeLens"]';
  hideCodeLensButton = '//button[normalize-space(text())="Hide Codelens"]';
  showInCodeLensButton = '//button[normalize-space(text())="Show in CodeLens"]';
  codeLensVisualizer = '#hw_in_c_codelens';
  question1Output = '#hw_in_c_stdout';
  question1Error = '#hw_in_c_errinfo';
  
  question2Section = '#lc2';
  question2Output = '#lc2_stdout';
  question2Error = '#lc2_errinfo';
  question2ShowSourceButton = '#lc2_src_show';
  question2HideSourceButton = '#lc2_src_hide';
  question2SourceBox = '#lc2_src .highlight pre';

  constructor(page: Page) {
    super(page);
    this.page = page;
  }


}


