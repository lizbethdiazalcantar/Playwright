import { Page, expect } from '@playwright/test';
import { TextbookPage } from '../textbookPage';

export class OverviewJava extends TextbookPage{
  page: Page;
  saveAndRunButton = '//button[normalize-space(text())="Save & Run"]';
  javaStandardOutput = '#lc1_stdout';
  javaErrorOutput = '#lc1_errinfo';
  inputForProgramEditBox = '#lc1_stdin';

  constructor(page: Page) {
    super(page);
    this.page = page;
  }
}