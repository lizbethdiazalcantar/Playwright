import { Page, expect } from '@playwright/test';
import { TextbookPage } from '../textbookPage';

export class ToggleQuestionTest extends TextbookPage{
  static locator(arg0: string) {
      throw new Error("Method not implemented.");
  }
  page: Page;

  constructor(page: Page) {
    super(page);
    this.page = page;
  }


}