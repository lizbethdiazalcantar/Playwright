import { Page, expect } from '@playwright/test';
import { TextbookPage } from '../textbookPage';

export class OverviewOcataveAndMatlab extends TextbookPage{
  page: Page;

  constructor(page: Page) {
    super(page);
    this.page = page;
  }

  //......Selectors.............//

  saveAndRunButton = '//button[@class="btn btn-success run-button"]'
  outPutArea = "#octave1_stdout"

}