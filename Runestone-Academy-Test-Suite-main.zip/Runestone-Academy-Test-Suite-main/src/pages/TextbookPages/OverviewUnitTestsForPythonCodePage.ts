import { Locator, Page, expect } from '@playwright/test';
import { TextbookPage } from '../textbookPage';

export class OverviewUnitTestsForPythonCodePage extends TextbookPage{
  page: Page;

  saveAndRunButton = '//button[normalize-space(text())="Save & Run"]';
  question5Output = '//*[@id="units1"]/div/div[4]';
  question5UnitTestsResultsTable = '//*[@id="units1_unit_results"]/table';
  question5ShowSourceCodeButton = '//*[@id="units1_src_show"]'; 
  question5HideSourceCodeButton = '//*[@id="units1_src_hide"]';
  question5UnitTestsResultsFeedback = '//*[@id="units1_unit_results"]/p';
  question5SourceCode = '//*[@id="units1_src"]/div/div/div/pre'; 
  question5SliderHandle = '//*[@id="units1"]/div/div[1]/div/div/a';
  question5SliderTrack = '//*[@id="units1"]/div/div[1]/div/div';
  question5CodeMirrorLine = '//*[@id="units1"]/div/div[2]/div'; 
  question5CodeCoach = '//*[@id="units1"]/div/div[3]';
  question5ErrorAlert = '//*[@id="units1_errinfo"]';

  constructor(page: Page) {
    super(page);
    this.page = page;
  }

  async dragSlider(
    page: Page,
    handletype: string | Locator,
    tracktype: string | Locator,
    from: number,
    to: number
) {
    const handle = typeof handletype === 'string'
    ? page.locator(handletype)
    : handletype;

    const track = typeof tracktype === 'string'
    ? page.locator(tracktype)
    : tracktype;

    await expect(handle).toBeVisible();
    await expect(track).toBeVisible();
    
    const sliderHandle = await handle.boundingBox();
    const sliderTrack = await track.boundingBox();

    if (!sliderHandle || !sliderTrack) {
        throw new Error('not visible');
    }

    // const xHandle = sliderHandle.x + sliderHandle.width / 2;
    const yHandle = sliderHandle.y + sliderHandle.height / 2;

    const trackFrom = sliderTrack.x + (sliderTrack.width * from) / 100;
    const trackTo = sliderTrack.x + (sliderTrack.width * to) / 100;

    await page.mouse.move(trackFrom, yHandle)
    await page.mouse.down();
    await page.mouse.move(trackTo, yHandle, {steps:10})
    await page.mouse.up();
  }

  async goToUnitTestsForPythonCodePage(): Promise<void> {
    // Replace the URL below with the actual URL of the Unit Tests for Python Code page
    await this.page.goto('/ns/books/published/overview/ActiveCode/python.html#unit-tests-for-python-code');
  }
}