import { Locator, Page, expect } from '@playwright/test';
import { TextbookPage } from '../textbookPage';

export class OverviewGraphsAndChartsPage extends TextbookPage{
  page: Page;
 
  saveAndRunButton = '//button[normalize-space(text())="Save & Run"]';
  question4Output = '#alt_kiva_bar1'; 
  question4Graph = '//*[@id="alt_kiva_bar1_graphics"]';
  question4ShowSourceCode = '//*[@id="alt_kiva_bar1_rev_show"]'; //*[@id="alt_kiva_bar1_rev_show"]
  question4HideSourceCode = '//*[@id="alt_kiva_bar1_rev_hide"]';
  question4SourceCodeOutput = '//*[@id="alt_kiva_bar1_rev"]/div/div/div/pre';
  GraphsAndChartsSliderHandle = '//*[@id="alt_kiva_bar1"]/div/div[1]/div/div/a';
  GraphsAndChartsSliderTrack = '//*[@id="alt_kiva_bar1"]/div/div[1]/div/div';
  question4CodeLine = `//*[@id="alt_kiva_bar1"]/div/div[3]`;
  question4CodeCoach = `//*[@id="alt_kiva_bar1"]/div/div[4]`;
  question4ErrorAlert = `//*[@id="alt_kiva_bar1_errinfo"]`;
  question4EmptyOutput = `//*[@id="alt_kiva_bar1_stdout"]`;

  constructor(page: Page) {
    super(page);
    this.page = page;
  }

  async dragSlider(
    page: Page,
    handletype: string | Locator,
    tracktype: string | Locator,
    from: number,
    to: number
) {
    const handle = typeof handletype === 'string'
    ? page.locator(handletype)
    : handletype;

    const track = typeof tracktype === 'string'
    ? page.locator(tracktype)
    : tracktype;

    await expect(handle).toBeVisible();
    await expect(track).toBeVisible();
    
    const sliderHandle = await handle.boundingBox();
    const sliderTrack = await track.boundingBox();

    if (!sliderHandle || !sliderTrack) {
        throw new Error('not visible');
    }

    // const xHandle = sliderHandle.x + sliderHandle.width / 2;
    const yHandle = sliderHandle.y + sliderHandle.height / 2;

    const trackFrom = sliderTrack.x + (sliderTrack.width * from) / 100;
    const trackTo = sliderTrack.x + (sliderTrack.width * to) / 100;

    await page.mouse.move(trackFrom, yHandle)
    await page.mouse.down();
    await page.mouse.move(trackTo, yHandle, {steps:10})
    await page.mouse.up();
  }
  
   async goToGraphsAndChartsPage(): Promise<void> {
        // Replace the URL below with the actual URL of the Graphs and Charts page
        await this.page.goto('/ns/books/published/overview/ActiveCode/python.html#graphs-and-charts');
}
}