import { Locator, Page, expect } from '@playwright/test';
import { TextbookPage } from '../textbookPage';

export class OverviewHiddenUnitTestsWithGraphicalStatusPage extends TextbookPage{
  page: Page;

  saveAndRunButton = '//button[normalize-space(text())="Save & Run"]';
  question6Output = `//*[@id="units2_stdout"]`; 
  question6HiddenUnitTestsResultsTable = `//*[@id="units2_unit_results"]`;
  question6HiddenUnitTestsResultsFeedback = `//*[@id="units2_unit_results"]/p`;
  question6ShowSourceCodeButton = `//*[@id="units2_src_show"]`;
  question6SourceCode = `//*[@id="units2_src"]/div/div/div/pre`;
  question6HideSourceCodeButton = `//*[@id="units2_src_hide"]`; 
  question6SliderHandle = `//*[@id="units2"]/div/div[2]/div/div/a`;
  question6SliderTrack = `//*[@id="units2"]/div/div[2]/div/div`;
  question6CodeMirrorLine = `//*[@id="units2"]/div/div[3]`;
  question6CodeCoach = `//*[@id="units2"]/div/div[4]`;
  question6ErrorAlert = `//*[@id="units2_errinfo"]`;

  
  constructor(page: Page) {
    super(page);
    this.page = page;
  }

  async dragSlider(
    page: Page,
    handletype: string | Locator,
    tracktype: string | Locator,
    from: number,
    to: number
) {
    const handle = typeof handletype === 'string'
    ? page.locator(handletype)
    : handletype;

    const track = typeof tracktype === 'string'
    ? page.locator(tracktype)
    : tracktype;

    await expect(handle).toBeVisible();
    await expect(track).toBeVisible();
    
    const sliderHandle = await handle.boundingBox();
    const sliderTrack = await track.boundingBox();

    if (!sliderHandle || !sliderTrack) {
        throw new Error('not visible');
    }

    // const xHandle = sliderHandle.x + sliderHandle.width / 2;
    const yHandle = sliderHandle.y + sliderHandle.height / 2;

    const trackFrom = sliderTrack.x + (sliderTrack.width * from) / 100;
    const trackTo = sliderTrack.x + (sliderTrack.width * to) / 100;

    await page.mouse.move(trackFrom, yHandle)
    await page.mouse.down();
    await page.mouse.move(trackTo, yHandle, {steps:10})
    await page.mouse.up();
  }

async goToHiddenUnitTestsWithGraphicalStatusPage(): Promise<void> {
    // Replace the URL below with the actual URL of the Hidden Unit Tests with Graphical Status page
    await this.page.goto('/ns/books/published/overview/ActiveCode/python.html#hidden-unit-tests-with-graphical-status');
  }
}