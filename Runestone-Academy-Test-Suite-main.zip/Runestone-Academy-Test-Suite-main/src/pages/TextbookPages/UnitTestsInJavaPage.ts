import { Locator,Page, expect } from '@playwright/test';
import { TextbookPage } from '../textbookPage';

export class UnitTestsInJava extends TextbookPage{
  page: Page;

  constructor(page: Page) {
    super(page);
    this.page = page;
  }
//Locator Strings

//Buttons
saveAndRunButton = '//button[contains(text(), "Save & Run")]';
showSourceButton = '#junit_src_show';
hideSourceButton = '#junit_src_hide';
reformatButton = '//*[@id="jUnitTesting2"]/div/div[2]/button[3]'; 
showCodeLensButton = '#jUnitTesting2 > div > div.ac_actions > button:nth-child(3)';
hideCodeLensButton = '//*[@id="jUnitTesting2"]/div/div[2]/button[2]';
saveAndRunButtonRiddle = '//button[contains(text(), "Save & Run")]'; //nth(2)
riddlesReformatButton = '//*[@id="jUnitTesting3"]/div/div[2]/button[3]';
riddlesShowCodeLensButton = '//*[@id="jUnitTesting3"]/div/div[2]/button[2]';
riddlesHideCodeLensButton = '//*[@id="jUnitTesting3"]/div/div[2]/button[2]';
riddlesShowSourceButton = '#jUnitTesting3_src_show';
riddlesHideSourceButton = '#jUnitTesting3_src_hide';

//Sliders
forLoopSliderHandle = '#jUnitTesting2 > div > div.ac_actions > div > div > a';
forLoopSliderTrack = '#jUnitTesting2 > div > div.ac_actions > div > div';
riddlesSliderHandle = '//*[@id="jUnitTesting3"]/div/div[2]/div/div/a';
riddlesSliderTrack = '//*[@id="jUnitTesting3"]/div/div[2]/div/div';

//Forms
sliderForm = '#jUnitTesting2 > div > div.ac_actions > div';
codeLens = '#jUnitTesting2';

//Others
forLoopOutputDisplay = '#jUnitTesting2_stdout';
showSourceCode = '#junit_src';
riddlesOutputArea = '#jUnitTesting3_unit_results';
riddlesOutputDisplay = '#jUnitTesting3_stdout';
riddlesCodeLens = '#jUnitTesting3_codelens';
riddlesShowSourceCode = '#jUnitTesting3_src';

//Others
forLoopCodeMirror = '#jUnitTesting2 > div > div.ac_code_div > div';
forLoopLineOfCode = '#jUnitTesting2 > div > div.ac_code_div > div > div.CodeMirror-scroll > div.CodeMirror-sizer > div > div > div > div.CodeMirror-code > div:nth-child(5) > pre';
lineOfCodeRiddle1 = '#jUnitTesting3 > div > div.ac_code_div > div > div.CodeMirror-scroll > div.CodeMirror-sizer > div > div > div > div.CodeMirror-code > div:nth-child(11) > pre';
lineOfCodeRiddle2 = '#jUnitTesting3 > div > div.ac_code_div > div > div.CodeMirror-scroll > div.CodeMirror-sizer > div > div > div > div.CodeMirror-code > div:nth-child(12) > pre';
lineOfSystemPrintQn = '//*[@id="jUnitTesting3"]/div/div[4]/div/div[6]/div[1]/div/div/div/div[5]/div[19]/pre';
lineOfSystemPrintAns = '//*[@id="jUnitTesting3"]/div/div[4]/div/div[6]/div[1]/div/div/div/div[5]/div[26]/pre';
OutputTextTable = '#jUnitTesting3_unit_results > span';

//Methods
async clickSaveAndRunButton(){
    const saveAndRunButton = this.page.locator(this.saveAndRunButton).nth(1);
    await saveAndRunButton.waitFor({state : 'visible'});
    console.log("Click the Save & Run button");
    await saveAndRunButton.click();
    }

async dragSlider(
    page: Page,
    handletype: string | Locator,
    tracktype: string | Locator,
    from: number,
    to: number
) {
    const handle = typeof handletype === 'string'
    ? page.locator(handletype)
    : handletype;

    const track = typeof tracktype === 'string'
    ? page.locator(tracktype)
    : tracktype;

    await expect(handle).toBeVisible();
    await expect(track).toBeVisible();
    
    const sliderHandle = await handle.boundingBox();
    const sliderTrack = await track.boundingBox();

    if (!sliderHandle || !sliderTrack) {
        throw new Error('not visible');
    }
    const yHandle = sliderHandle.y + sliderHandle.height / 2;

    const trackFrom = sliderTrack.x + (sliderTrack.width * from) / 100;
    const trackTo = sliderTrack.x + (sliderTrack.width * to) / 100;

    await page.mouse.move(trackFrom, yHandle)
    await page.mouse.down();
    await page.mouse.move(trackTo, yHandle, {steps:10})
    await page.mouse.up();
  }
  async clickReformatButton(){
    const reformatButton = this.page.locator(this.reformatButton).nth(0);
    await expect(reformatButton).toBeEnabled();   //To enable the button before the interaction
    console.log("Click the Reformat Button"); 
    await reformatButton.click();
  }
  async clickShowInCodeLensButton(){
     const showCodeLensButton = this.page.locator(this.showCodeLensButton).first()
     console.log("Click the Show in CodeLens Button"); 
     await showCodeLensButton.click();
     const codeLens = this.page.locator(this.codeLens).first();
     await this.waitForCodeLens(); 
     await expect(codeLens).toBeVisible();
     console.log("The codeLens is displayed");
  }
  async clickHideLensButton(){
     const showCodeLensButton = this.page.locator(this.showCodeLensButton).first()
     console.log("Click the Hide CodeLens Button"); 
     await showCodeLensButton.click();
     const codeLens = this.page.locator(this.codeLens).first();
     await this.waitForCodeLens(); 
     await expect(codeLens).toBeVisible();
     const hideCodeLensButton = this.page.locator(this.hideCodeLensButton).first();
     await expect(hideCodeLensButton).toBeEnabled();   //To enable the button before the interaction
     await hideCodeLensButton.click();
     console.log("The codeLens is hidden");
     const reformatButton = this.page.locator(this.reformatButton).first();
     await reformatButton.click();
  }
  async clickShowSourceButton(){
     const showSourceButton = this.page.locator(this.showSourceButton).first();
     console.log("Click the Show Source Code Button"); 
     await showSourceButton.click();
     const showSourceCode = this.page.locator(this.showSourceCode).first();
     await showSourceCode.waitFor({state : 'visible'});  
     console.log("Source code is displayed");
  }
  async clickHideSourceButton(){
     console.log("Click the Show Source Code Button"); 
     await this.page.locator('//*[@id="junit_src_show"]').first().click(); 
     const showSourceCode = this.page.locator(this.showSourceCode).first();
     await showSourceCode.waitFor({state : 'visible'});
     const hideSourceButton = this.page.locator('//*[@id="junit_src_hide"]').first();
     await expect(hideSourceButton).toBeEnabled();       //To enable the button before the interaction
     await (hideSourceButton).click();
     console.log("Click the Hide Source Code Button"); 
  
   
  }
  async clickSaveAndRunButtonRiddles(){
    const saveAndRunButtonRiddle = this.page.locator(this.saveAndRunButtonRiddle).nth(2);
    await saveAndRunButtonRiddle.waitFor({state : 'visible'});
    console.log("Click the Save & Run button");
    await saveAndRunButtonRiddle.click();
    await this.page.locator('text=Compiling and Running your Code Now... ').waitFor({state : 'detached'});
    const riddlesOutputArea = this.page.locator(this.riddlesOutputArea).nth(0);
    await expect(riddlesOutputArea).toBeVisible();
  }
  async clickReformatButtonRiddles(){
    const riddlesReformatButton = this.page.locator(this.riddlesReformatButton).first();
    await expect(riddlesReformatButton).toBeEnabled();   //To enable the button before the interaction
    console.log("Click the Reformat Button");
    await riddlesReformatButton.click();             
  }
  async clickShowInCodeLensButtonRiddles(){
    const riddlesShowCodeLensButton = this.page.locator(this.riddlesShowCodeLensButton).first()
    console.log("Click Show in CodeLens Button");
    await riddlesShowCodeLensButton.click();
    const riddlesCodeLens = this.page.locator(this.riddlesCodeLens).first();
    await this.waitForCodeLens(); 
    await expect(riddlesCodeLens).toBeVisible();
    console.log("The codeLens is displayed");
  }
  async clickHideCodeLensButtonRiddles(){
    const riddlesShowCodeLensButton = this.page.locator(this.riddlesShowCodeLensButton).first()
    await riddlesShowCodeLensButton.click();
    const riddlesCodeLens = this.page.locator(this.riddlesCodeLens).first(); 
    await this.waitForCodeLens(); 
    await expect(riddlesCodeLens).toBeVisible();
    const riddlesHideCodeLensButton = this.page.locator(this.riddlesHideCodeLensButton).first();
    await expect(riddlesHideCodeLensButton).toBeEnabled();  //To enable the button before the interaction
    console.log("Click the Hide Codelens Button");
    await riddlesHideCodeLensButton.click();
    console.log("The codeLens is hidden");
  }
  async clickShowSourceButtonRiddles(){
    const riddlesShowSourceButton = this.page.locator(this.riddlesShowSourceButton).first();
    console.log("Click the Show Source Code Button");
    await riddlesShowSourceButton.click();
    const riddlesShowSourceCode = this.page.locator(this.riddlesShowSourceCode).first();
    await riddlesShowSourceCode.waitFor({state : 'visible'});  
    console.log("Source code is displayed");
  }
  async clickHideSourceButtonRiddles(){
    const riddlesShowSourceButton = this.page.locator(this.riddlesShowSourceButton).first();
    console.log("Click the Hide Source Code Button");
    await riddlesShowSourceButton.click();
    const riddlesShowSourceCode = this.page.locator(this.riddlesShowSourceCode).first();
    await riddlesShowSourceCode.waitFor({state : 'visible'});
    const riddlesHideSourceButton = this.page.locator(this.riddlesHideSourceButton).first();
    await expect(riddlesHideSourceButton).toBeEnabled(); //To enable the button before the interaction
    await riddlesHideSourceButton.click();   
    console.log("Source code is hidden");  
  }
}
