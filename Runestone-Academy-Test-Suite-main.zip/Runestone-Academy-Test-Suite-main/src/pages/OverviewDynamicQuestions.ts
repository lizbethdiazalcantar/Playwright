import { Page, expect } from '@playwright/test';
import { TextbookPage } from './textbookPage';

export class OverviewDynamicQuestions extends TextbookPage{
  page: Page;

  checkMeButton ='//button[normalize-space(text())="Check Me"]';
  question1_2Output ='#question1_2_feedback';
  question1_2_Form = '#question1_2';
  redChoice = '#question1_2_opt_0';
  yellowChoice ='#question1_2_opt_1';
  blackChoice ='#question1_2_opt_2';
  greenChoice = '#question1_2_opt_3';
  
  showSourceButton='#dynamic_q_1_src_show';
  hideSourceButton='#dynamic_q_1_src_hide';
  compareMeButton ='#question1_2_bcomp';
  sourceCodeField = '#dynamic_q_1_src pre';

  constructor(page: Page) {
    super(page);
    this.page = page;
  }


}